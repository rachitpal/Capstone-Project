
<?php 
include('head.php');
include('mysqli_connect.php');
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$name = $_POST['name'];
	$email = $_POST['email'];
	$message = $_POST['message'];
	$t=time();
	echo $date = date("Y-m-d",$t);
	if(strlen($name) < 1 || strlen($email) < 1  || strlen($message) < 1 )
	{
		echo "Please fill all the fields";
	}
	else
	{
		$Q = "INSERT INTO contact SET name ='$name',email='$email',postDate= '$date',message='$message' ";
		if (mysqli_query($dbc, $Q)) {
	    echo "Your message has been sent. We will contact you soon.";
		} else {
		    echo "Something wnt wrong, Please try again later.";
		}
	}
}
    
?>  

<div class="container">
	<h1 class="text-center design">Contact Us</h1>
  <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="pname" placeholder="Enter your full name" name="name">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" placeholder="example@email.com" name="email">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="message">Message:</label>
      <div class="col-sm-10">
        <textarea name="message" class="form-control"></textarea>
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="sb" class="btn btn-success">Submit</button>
      </div>
    </div>
  </form>

  <div class="row">
  	<h1 class="text-center design">Find Us: </h1>
  	<div class="text-center">
  		<a href="https://goo.gl/maps/bksYZFPCtdiasfR66" target="_blank">
  			<img src="image/map.png">
  		</a>
  	</div>
  	<div class="col-md-4 col-md-offset-2">
  		<h1>Address:</h1>
  		299 Doon Valley Dr,<br> Kitchener, <br>ON N2G 4M4
  	</div>
  	<div class="col-md-4 col-md-offset-2">
  		<h1>Contact:</h1>
  		+1 (647) 434 7677<br>
  		<a href="">info@techshop.com</a>

  	</div>
  </div>
</div>
<?php 
include('footer.php');
?> 
