
<?php 
include('head.php');
include('mysqli_connect.php');

    
?>  

<div class="container">
  
</div>
<?php 
include('footer.php');
?> 
