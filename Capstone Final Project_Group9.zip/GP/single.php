
<?php 
include('head.php');
include('mysqli_connect.php');

    
?>  

<div class="container">
  
  

  <div class="row" id="single">
  	<?php 
    if(isset($_GET['p']))
    {
        $p = $_GET['p'];
        $sql = "SELECT * FROM products WHERE ProductId = '$p' ";
        $result = $dbc->query($sql);
        if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   
  	
  ?>
  <h1 class="design text-center"><?php echo $row['ProductName']; ?></h1>
  	<div class="col-md-6" id="Pimg">
  		<img src="admin/<?php echo $row['image']; ?>" height="auto" width="500px">
  		
  	</div>

    <div class="col-md-6" id="Pinfo">
      <div class="infop">
      <div class="names">
        Product :<br>
        Price :<br>
        Brand:<br>
      </div>
      <div id="values">
        <?php echo $row['ProductName']; ?><br>
        $<?php echo $row['Price']; ?><br>
        <?php echo $row['Brand']; ?>  <br>
        </div>
      </div>
      <div id="Description"><?php echo $row['Description']; ?></div>
      <form method="POST" action="checkout.php" style="text-align: center;margin-top: 10%;">
        <input type="hidden" name="pname" value="<?php echo $row['ProductName']; ?>">
        <input type="hidden" name="pid" value="<?php echo $row['ProductId']; ?>">
        <input type="hidden" name="pPrice" value="<?php echo $row['Price']; ?>">
        <input type="submit" name="sb" class="btn btn-success" value="Add To Cart">
      </form>
    </div>

  	<?php 
         }
}
}
?>
  </div>

  
</div>
<?php 
include('footer.php');
?> 
