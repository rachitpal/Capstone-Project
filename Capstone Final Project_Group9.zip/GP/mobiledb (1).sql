-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2020 at 06:07 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobiledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Username`, `Password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CategoryId` int(11) NOT NULL,
  `CategoryName` varchar(50) NOT NULL,
  `CategoryImg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CategoryId`, `CategoryName`, `CategoryImg`) VALUES
(1, 'Handset', 'images/category/Handset.png'),
(2, 'Earphones', 'images/category/Earphones.jpg'),
(3, 'Charger', 'images/category/Charger.jpg'),
(4, 'Data Cables', 'images/category/Data Cables.jpg'),
(5, 'Covers test', 'images/category/Covers.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL,
  `postDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Id`, `name`, `email`, `message`, `postDate`) VALUES
(1, 'ee', '0', 'rryhtejgrjgfn', '2020-04-12'),
(2, 'gregpk', 'rahul@ggg.com', 'erhgjfjhdjfg,jhghjfg,jhrdgf', '2020-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerId` int(11) NOT NULL,
  `CustomerName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerId`, `CustomerName`, `Email`, `password`, `Address`, `Gender`) VALUES
(1, 'test', 'test@test', '111', 'huyfuh767', 'female'),
(15, 'test1', 'Test@test.com', '111', 'test address', 'male'),
(18, 'rahul', 'rahul@ggg.com', '111', 'ggfjhishdsfh', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderId` int(11) NOT NULL,
  `ProductId` int(11) NOT NULL,
  `CustomerId` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderId`, `ProductId`, `CustomerId`, `Total`, `Status`) VALUES
(1, 1, 1, 1199, 'Shipped'),
(2, 1, 1, 1199, 'Recieved'),
(3, 1, 1, 1199, 'Delivered'),
(4, 1, 1, 1199, 'Recieved'),
(5, 1, 1, 1199, 'Delivered'),
(6, 1, 1, 1199, 'Delivered'),
(7, 1, 1, 1199, 'Recieved'),
(8, 1, 1, 1199, 'Recieved'),
(9, 1, 1, 1199, 'Recieved'),
(10, 2, 15, 999, 'Recieved'),
(11, 2, 15, 999, 'Shipped'),
(13, 1, 18, 1199, 'Recieved');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductId` int(11) NOT NULL,
  `ProductName` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `Price` float NOT NULL,
  `Description` varchar(500) NOT NULL,
  `CategoryId` int(11) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductId`, `ProductName`, `image`, `Price`, `Description`, `CategoryId`, `Brand`, `stock`) VALUES
(1, 'iPhone 11', 'images/products/ip11.png', 1199, '        	Dual Camera\r\nNight Mode\r\nAll-Day Battery\r\nToughest Glass        ', 1, 'Apple', 99),
(2, 'Pixel 4 A', 'images/products/pixl4A.png', 999, '        	        	        	Wide Angled Camera\r\nDual Pixel\r\nFlexible OLED Display                        ', 1, 'Google', 97),
(13, 'Samsung S10', 'images/products/s10.jpg', 1200, '        	        Get the Samsung Galaxy S10 on financing. Affordable devices available at Rogers. Exclusive Offers. Reliable Coverage. Shop Online.', 1, 'Samsung', 70),
(16, 'iPhone XS', 'images/products/iphoneXS.jpg', 110, 'Slim and handy model. Great features.   ', 1, 'Apple', 100),
(17, 'Nokia 9 Pure View', 'images/products/Nokia9PureView.jpg', 1200, '        	    Pair your home and cellphone together with this easy-to-use system.    ', 1, 'Nokia', 100),
(18, 'Samsung Galaxy Edge II', 'images/products/SamsungGalaxyEdgeII.jpg', 999, '        	       Audio and visual alerts deliver text, email, social media, or voicemail notifications. ', 1, 'Samsung', 100),
(19, 'Samsung Galaxy One', 'images/products/SamsungGalaxyOne.png', 1500, '        	        	        Streamline your phone communications with this VTech three-handset cordless phone system with secure DECT 6.0 technology.        ', 1, 'Samsung', 100),
(20, 'Karl', 'images/products/karl.jpeg', 56, '        	Shure SE535 Wireless Earphones with Bluetooth 5.0, Sound Isolating, Limited Edition Red        ', 2, 'Karl', 20),
(21, 'Philips', 'images/products/philips.jpg', 40, '        	H1 Headphone Chip, Class 1 Bluetooth, 9 Hours Of Listening Time, Sweat Resistant Earbuds - Black        ', 2, 'Philips', 10),
(22, 'Samsung', 'images/products/samsung.jpg', 42, '        	The soft, ergonomic ear-tips that adapt to the shape of your inner ear.        ', 2, 'Samsung', 20),
(23, 'Xiaomi', 'images/products/xiaomi.jpg', 42, '        	      If you’re as much of a bass fan as we are, then you’ll adore these in-ear headphones.  ', 2, 'Xiaomi', 20),
(24, 'Apple', 'images/products/apple.jpeg', 49, '        	  Overall a very very good product       ', 3, 'Apple', 20),
(25, 'Nokia', 'images/products/nokia.jpg', 79, '        	        	        	        	    Flipkart SmartBuy 2A Fast Power Charger with Charge & Sync USB Cable.                        ', 3, 'Nokia', 20),
(26, 'Pixel', 'images/products/pixel.jpg', 59, '        Wall Charger\r\nSuitable For: Mobile\r\nUniversal Voltage	        ', 3, 'Pixel', 30),
(27, 'Samsung', 'images/products/samsung.jpg', 49, 'Charger\r\nSuitable For: Mobile\r\nUniversal Voltage      ', 3, 'Samsung', 50),
(28, 'Apple', 'images/products/apple.jpeg', 59, '        	Excellent product and great quality        ', 4, 'Apple', 30),
(29, 'Samsung', 'images/products/samsung.jpg', 49, '        	   High quality product     ', 4, 'Samsung', 10),
(30, 'USB 30 Pin', 'images/products/usb30pin.jpg', 29, '        	   Affordable and easy to use     ', 4, 'USB', 50),
(31, 'USB C', 'images/products/usb-c.jpg', 39, '        Used for C type devices	        ', 4, 'USB', 50),
(32, 'Galaxy Note 10', 'images/products/galaxynote10.jpg', 59, '        	        	   Shiny and attractive             ', 1, 'Samsung', 70),
(33, 'Galaxy S 10', 'images/products/GalaxyS10.jpg', 49, '        	    Super cute    ', 5, 'Samsung', 100),
(34, 'iPhone', 'images/products/iPhone.jpg', 59, '        	Cute, light weight and durable        ', 5, 'Apple', 22),
(35, 'iPhone 11 Pro', 'images/products/iphone11pro.jpg', 29, '        	 Light weight, cute, and attractive       ', 5, 'Apple', 50),
(36, 'iPhone XS', 'images/products/iphoneXS.jpg', 39, '        	Stylish and sleak        ', 5, 'Apple', 60),
(37, 'Earphones', 'images/products/philips.jpg', 34, 'Good Quality Earphones    ', 2, 'Philips', 100),
(38, 'Earphones 2', 'images/products/samsung.jpg', 22.3, 'Samsung Earphones  ', 2, 'Samsung', 100),
(39, 'Earphones', 'images/products/karl.jpeg', 22.22, 'Karl Earphones    ', 2, 'Karl', 100),
(40, 'Xiaomi Earphones', 'images/products/xiaomi.jpg', 30.45, 'Xiaomi Earphones Good Quality        	        ', 2, 'Xiaomi', 100),
(41, 'C Type', 'images/products/samsung.jpg', 88, 'C type charger cable         ', 3, 'Samsung', 100),
(42, 'Nokia Charger', 'images/products/nokia.jpg', 30.34, 'Nokia Phone Charger       ', 3, 'Nokia', 100),
(43, 'Apple Charger', 'images/products/apple.jpeg', 44, '        	Apple phone charger        	                ', 3, 'Apple', 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryId`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerId`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `CategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
