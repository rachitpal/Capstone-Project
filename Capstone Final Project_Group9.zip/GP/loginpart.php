<ul class="nav navbar-nav navbar-right">
      <?php 
      if(isset($_SESSION['user']))
      {
?>
<li><a href="#"><span class="glyphicon glyphicon-user"></span>Hello,<?php echo $_SESSION['user']; ?></a>
  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
<?php
      }
      else
      {


      ?>
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    <?php } ?>
    </ul>