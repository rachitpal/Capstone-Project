
<?php 
include('head.php');
include('mysqli_connect.php');
?>  

<div class="container">

    
    <div class="row" id="products">
    <?php 
    if(isset($_GET['cat']))
    {
        $cat = $_GET['cat'];
    $sql = "SELECT * FROM products WHERE CategoryId = '$cat' ";
    $result = $dbc->query($sql); 
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
   
   
    ?>
    <div class="col-md-4">
        <a href="single.php?p=<?php echo $row['ProductId']; ?>">
        <img src="admin/<?php echo $row['image']; ?>" height="150px" width="auto">
        <div class="infop">
      <div class="names">
        Product :<br>
        Price :<br>
        Brand:<br>
      </div>
      <div id="values">
        <?php echo $row['ProductName']; ?><br>
        $<?php echo $row['Price']; ?><br>
          <?php echo $row['Brand']; ?>  <br>
        </div>
      </div>
        </a>
    </div>
    <?php 
         }
    }else
    {
        echo "No result Found";
    }
    }
    ?>
</div>
    

<?php 
include('footer.php');
?> 
