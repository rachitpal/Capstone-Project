<?php 
include('head.php');
include('mysqli_connect.php');
?>
<div class="container">
<?php
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$error = array();
	$pid = $_POST['pid'];
	$price = $_POST['price'];
	if(empty($_POST['cname']) || strlen($_POST['cname']) < 1)
	{
		array_push($error, "Please enter valid Name");
	}
	else
	{
		$name = $_POST['cname'];
	}

	if(empty($_POST['email']) || strlen($_POST['email']) < 1)
	{
		array_push($error, "Please enter valid Email");
	}
	else
	{
		$email = $_POST['email'];
	}

	if(empty($_POST['address']) || strlen($_POST['address']) < 1)
	{
		array_push($error, "Please enter valid address");
	}
	else
	{
		$address = $_POST['address'];
	}

	if(empty($_POST['gender']) || strlen($_POST['gender']) < 1)
	{
		array_push($error, "Please Select gender");
	}
	else
	{
		$gender = $_POST['gender'];
	}

	if(empty($_POST['payment']) || strlen($_POST['payment']) < 1)
	{
		array_push($error, "Please Select payment");
	}
	else
	{
		$payment = $_POST['payment'];
	}


	if(empty($error))
	{
		$sql = "INSERT INTO customers (CustomerName, Email, Address,Gender)
			VALUES ('$name', '$email', '$address','$gender')";
		$update = " SELECT * FROM products WHERE ProductId = '$pid' ";
		$result = $dbc->query($update);
		 $rowStock = $result->fetch_assoc();
		 $old_stock = $rowStock['stock'];

		
		if ($dbc->query($sql) === TRUE) {
    		$CustomerId = $dbc->insert_id;
    		$sql1 = "INSERT INTO orders (ProductId, CustomerId, Total,Status)
			VALUES ('$pid', '$CustomerId', '$price','Approved')";
    		if($dbc->query($sql1) === TRUE)
    		{
    			$new_stock = $old_stock - 1;
    			 $updateQuery = "UPDATE products SET stock = '$new_stock' WHERE ProductId = '$pid' ";
    			if($dbc->query($updateQuery))
    			{
    				$success = TRUE;
    				echo "Thank youu for shopping";
    			}
    		}
    		else
    		{
    			// echo "error".$dbc -> error;
    			$success = False;
    		}
		}
		else
		{
			echo $dbc->error;
		}
	}
	else
	{
		print_r($error);
	}
}
?>

</div>

<?php 
include('footer.php');
?> 