
<?php 
include('head.php');
include('mysqli_connect.php');
?>  

<div class="container">
  <div class="jumbotron" id="banner">
      <div class="container text-center">
        <h1>Tech Shop</h1>      
        <p>One Store For All Tech Need</p>
      </div>
</div>
    
    <div class="row" id="category">
      <h1 class="text-center design">Explore Our Categories</h1>
    <?php 
    $sql = "SELECT * FROM category LIMIT 3";
    $result = $dbc->query($sql); 
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    ?>
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading"><?php echo $row['CategoryName']; ?></div>
        <div class="panel-body"><img src="admin/<?php echo $row['CategoryImg']; ?>" class="img-responsive" alt="<?php echo $row['CategoryName']; ?>"></div>
        <div class="panel-footer"><a href="category.php?cat=<?php echo $row['CategoryId']; ?>">Explore</a></div>
      </div>
    </div>
    <?php 
    }
    }
    ?>
</div>
    
<div class="row" id="brands">
    <h1 class="text-center design">Brands We Offer</h1>
    <div class="col-md-3">
     <a href="https://www.apple.com/" target="_blank"> <img src="image/apple.png" width="200px" height="100%" ></a>
    </div>
    <div class="col-md-3">
      <a href="https://store.google.com/" target="_blank"><img src="image/google.png" width="200px" height="100%" ></a>
    </div>
    <div class="col-md-3" id="samsung">
      <a href="https://www.samsung.com/ca/" target="_blank"><img src="image/samsung1.png" width="200px" height="100%" ></a>
    </div>
    <div class="col-md-3">
      <a href="https://www.skullcandy.com/" target="_blank"><img src="image/skull.png" width="200px" height="100%" ></a>
    </div>
</div>
<?php 
include('footer.php');
?> 
