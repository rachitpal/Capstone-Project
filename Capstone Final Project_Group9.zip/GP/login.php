<?php 
include('head.php');
include('mysqli_connect.php');
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
  echo  $email = $_POST['email'];
    $password = $_POST['password'];
    if(strlen($email) < 1 || strlen($password) < 1)
    {
        echo "Please fill fields.";
    }
    else
    {
    $Query = $dbc->query("SELECT * FROM customers WHERE Email = '$email' AND password = '$password' ");
    if($Query->num_rows > 0)
      {
       while($row = $Query->fetch_assoc()) 
       { 
            $_SESSION['user'] = $email;
            header("Location: home.php");
       }
    }
    else
    {
        echo "No user found.";
    }

}
}
?>  

 <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h3 class="card-title text-center">Sign In</h3>
            <form class="form-signin" method="POST" action="">
              <div class="form-label-group">
                <label for="inputEmail">Email address</label>
                <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required autofocus>
                
              </div>

              <div class="form-label-group">
                  <label for="inputPassword">Password</label>
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
              
              </div>

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Sign in</button>
              <hr class="my-4">
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php 
include('footer.php');
?> 
