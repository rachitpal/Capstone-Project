<?php 
include('head.php');
include('mysqli_connect.php');
?>
<div class="container">
<?php
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
?>
	<div class="col-md-6 col-md-offset-3">
		<div class="left">
			Product:<br>
			Price:<br>
			Quantity:
		</div>
		<div class="right">
			<?php 
        $pID = $_POST['pid'];
				echo $pName = "<span class='val'>".$_POST['pname']."</span><br>";
				echo $price = "<span class='val'>$".$_POST['pPrice']."</span><br>";
				echo $quantity = "<span class='val'>1</span><br>";
			?>
		</div>
	</div>
<?php
}
?>
<div class="col-md-12">
<form class="form-horizontal" action="thankyou.php" method="POST">
  <input type="hidden" name="pname" value="<?php echo $_POST['pname']; ?>">
  <input type="hidden" name="price" value="<?php echo $_POST['pPrice']; ?>">
  <input type="hidden" name="pid" value="<?php echo $_POST['pid']; ?>">
    <div class="form-group">
      <label class="control-label col-sm-2" for="cname">Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="cname" placeholder="Full Name" name="cname">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="example@email.com" name="email">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="address">Address:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="address" placeholder="Address" name="address">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="gender">Gender:</label>
      <div class="col-sm-10">
        <input type="radio" class="form-controll" value="male" id="male" name="gender">Male
        <input type="radio" class="form-controll" value="female" id="female" name="gender">Female
      </div>
    </div>

      <div class="form-group">
      <label class="control-label col-sm-2" for="payment">Payment:</label>
      <div class="col-sm-10">
        <select name="payment" class="form-control">
          <option value="credit">Credit</option>
          <option value="debit">Debit</option>
          <option value="cod">COD</option>
        </select>
      </div>
    </div>

    <div class="form-group">
      <div class="col-sm-4 col-sm-offset-4">
        <input type="submit" class="btn btn-info" id="submit" name="submit" value="Checkout">
      </div>
    </div>
	
</form>
</div>
</div>
<?php 
include('footer.php');
?> 