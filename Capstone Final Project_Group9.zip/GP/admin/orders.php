<?php 
include('head.php');
include('../mysqli_connect.php')
?>
<div class="container">
<table class="table table-hover">
    <thead>
      <tr>
        <th>Id</th>
        <th>Product</th>
        <th>Customer</th>
        <th>Total</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $Query = $dbc->query("SELECT * FROM orders");
      if($Query->num_rows > 0)
      {
       while($row = $Query->fetch_assoc()) 
       { 
       $pid1 = $row['ProductId'];
        $csid = $row['CustomerId'];
      ?>
      <tr>
        <td><?php echo $row['OrderId'] ?></td>
        <td><?php 
        $Query1 = $dbc->query("SELECT ProductName FROM products WHERE ProductId = '$pid1' ");
        $r = $Query1->fetch_assoc(); 
        echo $r['ProductName'];
        ?> </td>
        <td><?php 
        $Query2 = $dbc->query("SELECT CustomerName FROM customers WHERE CustomerId = '$csid' ");
        $r2 = $Query2->fetch_assoc(); 
        echo $r2['CustomerName'];
        ?> </td>
        <td><?php echo $row['Total'] ?> </td>
        <td><?php echo $row['Status'] ?> </td>
        <td><a href="editOrder.php?Id=<?php echo $row['OrderId']; ?>">more</a></td>
      </tr>
      <?php 
  }
}
      ?>
    </tbody>
  </table>
</div>
<?php 
include('footer.php');
?>