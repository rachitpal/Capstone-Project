<?php 

include('head.php');
include('../mysqli_connect.php');
if(isset($_GET['session']))
{
	unset($_SESSION['data']);
}
if(isset($_GET['Id']))
{
	$id = $_GET['Id'];
	$Q = "SELECT * FROM products WHERE ProductId = '$id' ";
	$result = $dbc->query($Q);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$_SESSION['data'] = $row;
		}
    }
}
else
{
	
}
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$target_dir = "images/products/";
	$target_file = $target_dir . basename($_FILES["pimg"]["name"]);
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	$name = $_POST['pname'];
	$cat = $_POST['prntID'];
	$price = $_POST['price'];
	$desc = $_POST['desc'];
	$brand = $_POST['brand'];
	$stock = $_POST['stock'];

	if(empty($name) || strlen($name) < 1)
	{
		echo "Please enter Product Name";
	}
	if(empty($cat) || strlen($cat) < 1)
	{
		echo "Please select Category Name";
	}
	if(empty($price) || strlen($price) < 1)
	{
		echo "Please enter price";
	}
	if(empty($desc) || strlen($desc) < 1)
	{
		echo "Please enter  Description";
	}
	if(empty($brand) || strlen($brand) < 1)
	{
		echo "Please enter  brand";
	}
	if(empty($stock) || strlen($stock) < 1)
	{
		echo "Please enter  stock";
	}
	if(isset($_SESSION['data']))
	{
		
		if(empty($imageFileType) || strlen($imageFileType) < 1)
		{
			$img = $_SESSION['data']['image'];
			move_uploaded_file($_FILES["pimg"]["tmp_name"], $img);
		}
		else
		{
			move_uploaded_file($_FILES["pimg"]["tmp_name"], $target_file);
			$img = $target_file;
		}
	}
	else
	{
		if(empty($imageFileType) || strlen($imageFileType) < 1)
		{
			echo "Please select Image";
		}
		else
		{
			move_uploaded_file($_FILES["pimg"]["tmp_name"], $target_file);
		}
	}
	

	if(isset($_SESSION['data']))

	{
		$Q2 = "UPDATE products SET ProductName ='$name',price='$price',Description='$desc',CategoryId='$cat',Brand='$brand',stock='$stock',image='$img' WHERE ProductId='$id' ";
		if (mysqli_query($dbc, $Q2)) {
			echo "success";
		} else {
		    echo "Error: " . $Q2 . "<br>" . $dbc->error;
		}
	}
	else
	{
		$Q = "INSERT INTO products SET ProductName ='$name',price='$price',Description='$desc',CategoryId='$cat',Brand='$brand',stock='$stock',image='$target_file' ";
		if (mysqli_query($dbc, $Q)) {
	    echo "New record created successfully";
		} else {
		    echo "Error: " . $Q . "<br>" . $dbc->error;
		}
	}

}


if (isset($_POST['delete'])) {
	echo "delete";
	$id = $_GET['Id'];
	$q = "DELETE FROM products WHERE ProductId= $id ";
	if($dbc->query($q) === TRUE)
	{
		echo "Product deleted successfully<br>";
		echo "<a href='products.php' >BACK</a>";
	}
}

?>
<div class="container">
<form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2" for="pname">Product Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="pname" placeholder="Name of Product" name="pname" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['ProductName']; } ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="cname">Category Name:</label>
      <div class="col-sm-10">
      	<select name="prntID">
      		<?php 
      		$Q2 = "SELECT * FROM category";
			$result2 = $dbc->query($Q2);
      		if ($result2->num_rows > 0) {
				while($row2 = $result2->fetch_assoc()) {
					$_SESSION['parentdata'] = $row2;
					
      		?>
      		<option
      		<?php
      		if(isset($_GET['parent']))
      		{
      			if($row2['catID'] == $parentid)
					{
						echo "selected = selected";
					}
      		}
      		
      		?>
      		value="<?php echo $row2['CategoryId']; ?>"><?php echo $row2['CategoryName']; ?></option>
      		<?php 
      			}
			}
      		?>
      	</select>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="price">Price:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="price" placeholder="Price" name="price" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['Price']; } ?>">
      </div>
    </div>



    <div class="form-group">
      <label class="control-label col-sm-2" for="desc">Product Description:</label>
      <div class="col-sm-10">
        <textarea name="desc" id="desc">
        	<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['Description']; } ?>
        </textarea>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="brand">Brand:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="brand" placeholder="Brand" name="brand" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['Brand']; } ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="stock">Stock:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="stock" placeholder="Stock" name="stock" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['stock']; } ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="pimg">Product Image</label>
      <div class="col-sm-10"> 
      <?php if(!empty($_SESSION['data'] )){ ?>
      	<img src="<?php echo $_SESSION['data']['image']; ?>" height="100px" width="100px">
      <?php } ?>
           
        <input type="file" class="form-control" id="pimg" placeholder="Image" name="pimg" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['image']; } ?>">
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="sb" class="btn btn-default">Submit</button>
        <button type="submit" name="delete" id="delete1" class="btn btn-danger">Delete</button>
      </div>
    </div>
  </form>
 </div>
<?php 
include('footer.php');
?>