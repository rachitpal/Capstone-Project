<?php 
session_start();
if(isset($_SESSION['admin']))
{
  
}
else
{
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><?php echo "Welcome, ".$_SESSION['admin']; ?></a>
    </div>
    <ul class="nav navbar-nav">
<!--       <li ><a href="index.php">Home</a></li> -->
      <li class="active"><a href="category.php">Categories</a></li>
      <li><a href="products.php">Products</a></li>
      <li><a href="orders.php">Orders</a></li>
      <li><a href="customers.php">Customers</a></li>
    </ul>
    <ul id="right" class="nav navbar-nav">
      <li id="logout"><a href="logout.php">Logout</a></li>
    </ul>
  </div>
</nav>