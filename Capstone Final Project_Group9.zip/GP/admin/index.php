<?php 
if(isset($_SESSION["data"]))
{
  unset($_SESSION["data"]);
}
include('head.php');
include('../mysqli_connect.php');
?>
<h1>Welcome,<?php echo $_SESSION['admin']; ?></h1>
<?php 
include('footer.php');
?>