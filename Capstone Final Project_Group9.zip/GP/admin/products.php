<?php 
if(isset($_SESSION["data"]))
{
  unset($_SESSION["data"]);
}

include('head.php');
include('../mysqli_connect.php')
?>
<div class="container">
  <span id="addNew"><a href="editProduct.php?session=unset">Add Product</a></span>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Id</th>
        <th>Product Name</th>
        <th>Image</th>
        <th>Price</th>
        <th>Description</th>
        <th>Category</th>
        <th>Brand</th>
        <th>Inventory</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $Query = $dbc->query("SELECT * FROM products ");
      if($Query->num_rows > 0)
      {
       while($row = $Query->fetch_assoc()) 
       { 
        $catid = $row['CategoryId'];
      ?>
      <tr>
        <td><?php echo $row['ProductId'] ?></td>
        <td><?php echo $row['ProductName'] ?> </td>
        <td> <img src="<?php echo $row['image'] ?>" height="100px" width="100px"> </td>
        <td>$<?php echo $row['Price'] ?> </td>
        <td><?php echo $row['Description'] ?> </td>
        <td><?php 
        $Query1 = $dbc->query("SELECT CategoryName FROM category WHERE CategoryId = '$catid' ");
        $r = $Query1->fetch_assoc(); 
        echo $r['CategoryName'];
        ?> </td>
        <td><?php echo $row['Brand'] ?> </td>
        <td><?php echo $row['stock'] ?> </td>
        <td> <a href="editProduct.php?Id=<?php echo $row['ProductId']; ?>">more</a> </td>
      </tr>
      <?php 
  }
}
      ?>
    </tbody>
  </table>
</div>
<?php 
include('footer.php');
?>