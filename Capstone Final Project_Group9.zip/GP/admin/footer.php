
<script type="text/javascript">
	$(document).ready(function(){
    $("#delete").click(function(e){
        if(!confirm('Do you want to delete Category?')){
            e.preventDefault();
            return false;
        }
        return true;
    });
});
</script>
</body>
</html>