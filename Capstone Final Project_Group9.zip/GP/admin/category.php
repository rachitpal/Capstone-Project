<?php 
if(isset($_SESSION["data"]))
{
  unset($_SESSION["data"]);
}
include('head.php');
include('../mysqli_connect.php');
?>
<div class="container">
  <span id="addNew"><a href="editCat.php?session=unset">Add Category</a></span>
<table class="table">
    <thead>
      <tr>
        <th>Id</th>
        <th>Category Name</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $Query = $dbc->query("SELECT * FROM category");
      if($Query->num_rows > 0)
      {
       while($row = $Query->fetch_assoc()) 
       { 
      ?>
      <tr>
        <td><?php echo $row['CategoryId'] ?></td>
        <td><?php echo $row['CategoryName'] ?> </td>
        <td> <img src="<?php echo $row['CategoryImg'] ?>" height="100px" width="100px"> </td>
        <td> <a href="editCat.php?Id=<?php echo $row['CategoryId']; ?>">more</a> </td>
      </tr>
      <?php 
  }
}
      ?>
    </tbody>
  </table>
</div>
<?php 
include('footer.php');
?>