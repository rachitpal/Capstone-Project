<?php 

include('head.php');
include('../mysqli_connect.php');

if(isset($_GET['Id']))
{
	$id = $_GET['Id'];
	$Q = "SELECT * FROM orders WHERE OrderId = '$id' ";
	$result = $dbc->query($Q);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$_SESSION['data'] = $row;
		}
    }
    $pid = $_SESSION['data']['ProductId'];
    $Query1 = $dbc->query("SELECT ProductName FROM products WHERE ProductId = '$pid' ");
    $r = $Query1->fetch_assoc(); 
    $ProductName =  $r['ProductName'];

    $cid = $_SESSION['data']['CustomerId'];
    $Query2 = $dbc->query("SELECT CustomerName FROM customers WHERE CustomerId = '$cid' ");
    $r2 = $Query2->fetch_assoc(); 
    $CustomerName = $r2['CustomerName'];
}
else
{
	
}
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$staus = $_POST['status'];

	if(empty($staus) || strlen($staus) < 1)
	{
		echo "Please enter Status";
	}

	if(isset($_SESSION['data']))
	{
		$Q2 = "UPDATE orders SET Status ='$staus' WHERE OrderId='$id' ";
		if (mysqli_query($dbc, $Q2)) {
		} else {
		    echo "Error: " . $Q2 . "<br>" . $dbc->error;
		}
	}

}


if (isset($_POST['delete'])) {
	$id = $_GET['Id'];
	$q = "DELETE FROM orders WHERE OrderId= $id ";
	if($dbc->query($q) === TRUE)
	{
		echo "Order deleted";
	}
	
}

?>
<div class="container">
<form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2" for="cname">Product Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="cname" placeholder="Name of Product" name="cname" value="<?php echo $ProductName; ?>" readonly>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="cname">Customer Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="cname" placeholder="Name of Customer" name="cname" value="<?php echo $CustomerName; ?>" readonly>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="cname">Status:</label>
      <div class="col-sm-10">
        <select id="status" name="status">
        	<option>Approved</option>
        	<option>Shipped</option>
        	<option>Delivered</option>
        </select>
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="sb" class="btn btn-default">Submit</button>
        <button type="submit" name="delete" id="delete1" class="btn btn-danger">Delete</button>
      </div>
    </div>
  </form>
 </div>
<?php 
include('footer.php');
?>