<?php 

include('head.php');
include('../mysqli_connect.php');

if(isset($_GET['session']))
{
	unset($_SESSION['data']);
}

if(isset($_GET['Id']))
{
	$id = $_GET['Id'];
	$Q = "SELECT * FROM category WHERE CategoryId = '$id' ";
	$result = $dbc->query($Q);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$_SESSION['data'] = $row;
		}
    }
}
else
{
	
}
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$name = $_POST['cname'];
	$target_dir = "images/category/";
	$target_file = $target_dir . basename($_FILES["cimg"]["name"]);
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	echo $newImage = $target_dir.$name.".".$imageFileType;

	if(empty($name) || strlen($name) < 1)
	{
		echo "Please enter Category Name";
	}
	if(isset($_SESSION['data']))
	{
		
		if(empty($imageFileType) || strlen($imageFileType) < 1)
		{
			$img = $_SESSION['data']['CategoryImg'];
			move_uploaded_file($_FILES["cimg"]["tmp_name"], $img);
		}
		else
		{
			move_uploaded_file($_FILES["cimg"]["tmp_name"], $newImage);
			$img = $newImage;
		}
	}
	else
	{
		if(empty($imageFileType) || strlen($imageFileType) < 1)
		{
			echo "Please select Image";
		}
		else
		{
			move_uploaded_file($_FILES["cimg"]["tmp_name"], $newImage);
		}
	}
	

	if(isset($_SESSION['data']))

	{
		$Q2 = "UPDATE category SET CategoryName ='$name',CategoryImg='$img'WHERE CategoryId='$id' ";
		if (mysqli_query($dbc, $Q2)) {
		} else {
		    echo "Error: " . $Q2 . "<br>" . $dbc->error;
		}
	}
	else
	{
		$Q = "INSERT INTO category SET CategoryName ='$name',CategoryImg='$newImage' ";
		if (mysqli_query($dbc, $Q)) {
	    echo "New record created successfully";
		} else {
		    echo "Error: " . $Q . "<br>" . $dbc->error;
		}
	}

}


if (isset($_POST['delete'])) {
	echo "delete";
	$id = $_GET['Id'];
	$q = "DELETE FROM category WHERE CategoryId= $id ";
	if($dbc->query($q) === TRUE)
	{
		$delete = TRUE;
	}
	$q11 = $dbc->query("SELECT * FROM products WHERE CategoryId= $id ");
	  if($q11->num_rows > 0)
      {
       while($row = $q11->fetch_assoc()) 
       { 
       		$idp = $row['CategoryId'];
       		$qp = "DELETE FROM products WHERE CategoryId= $idp ";
			  if ($dbc->query($qp) === TRUE) {
			    $delete = TRUE;
			  }
			  else
			  {
			  	$delete = False;
			  }
       }
	}
	if($delete == TRUE)
	{
		echo "<br>Category Deleted.";
	}
}

?>
<div class="container">
<form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2" for="cname">Category Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="cname" placeholder="Name of Category" name="cname" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['CategoryName']; } ?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="cimg">Category Image</label>
      <div class="col-sm-10"> 
      <?php if(!empty($_SESSION['data'] )){ ?>
      	<img src="<?php echo $_SESSION['data']['CategoryImg']; ?>" height="100px" width="100px">
      <?php } ?>
           
        <input type="file" class="form-control" id="cimg" placeholder="Image" name="cimg" value="<?php if(!empty($_SESSION['data'] )){ echo $_SESSION['data']['CategoryImg']; } ?>">
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="sb" class="btn btn-default">Submit</button>
        <button type="submit" name="delete" id="delete1" class="btn btn-danger">Delete</button>
      </div>
    </div>
  </form>
 </div>
<?php 
include('footer.php');
?>