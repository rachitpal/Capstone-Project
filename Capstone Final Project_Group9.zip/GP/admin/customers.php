<?php 
include('head.php');
include('../mysqli_connect.php');

if(isset($_GET['delete']))
{
  $id = $_GET['delete'];
  $q = "DELETE FROM customers WHERE CustomerId= $id ";
  if ($dbc->query($q) === TRUE) {
    echo "<h3>Customer deleted successfuly</h3>";
  }
}
?>
<div class="container">
<table class="table table-hover">
    <thead>
      <tr>
        <th>Id</th>
        <th>Customer Name</th>
        <th>Email</th>
        <th>Address</th>
        <th>Gender</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $Query = $dbc->query("SELECT * FROM customers ");
      if($Query->num_rows > 0)
      {
       while($row = $Query->fetch_assoc()) 
       { 
      ?>
      <tr>
        <td><?php echo $row['CustomerId'] ?></td>
        <td><?php echo $row['CustomerName'] ?> </td>
        <td>$<?php echo $row['Email'] ?> </td>
        <td><?php echo $row['Address'] ?> </td>
        <td><?php echo $row['Gender'] ?> </td>
        <td> <a href="?delete=<?php echo $row['CustomerId']; ?>">delete</a> </td>
      </tr>
      <?php 
  }
}
      ?>
    </tbody>
  </table>
</div>
<?php 
include('footer.php');
?>